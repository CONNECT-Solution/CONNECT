/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the License).  You may not use this file except in
 * compliance with the License.
 * 
 * You can obtain a copy of the license at
 * https://woodstock.dev.java.net/public/CDDLv1.0.html.
 * See the License for the specific language governing
 * permissions and limitations under the License.
 * 
 * When distributing Covered Code, include this CDDL
 * Header Notice in each file and include the License file
 * at https://woodstock.dev.java.net/public/CDDLv1.0.html.
 * If applicable, add the following below the CDDL Header,
 * with the fields enclosed by brackets [] replaced by
 * you own identifying information:
 * "Portions Copyrighted [year] [name of copyright owner]"
 * 
 * Copyright 2007 Sun Microsystems, Inc. All rights reserved.
 */

package com.sun.webui.jsf.model.login;

/**
 * Constants needed by both the presention layer and the underlying
 * authentication infrastructure.
 *
 * @author Deep Bhattacharjee
 */
public class LoginConstants {
    
    /**
     * key to extract JVBC thread
     */
                                                                                                   
    public static final String LOGIN_THREAD = "loginThread";
                                                                                                   
    /**
     * key to extract client response
     */
                                                                                                   
    public static final String CLIENTCONV = "clientconv";
                                                                                                   
    /**
     * key to extract server response
     */
                                                                                                   
    public static final String SERVERCONV = "serverconv";
    
    /**
     * key to extract subject object from session.
     */
                                                                                                   
    public static final String SUBJECT = "subject";

    /**
     * key to extract the JAAS login exception
     */
                                                                                                   
    public static final String LOGINEXCEPTION =
                "jaasloginexception";

    public static enum LOGINSTATE {INIT, CONTINUE, FAILURE, SUCCESS}
    
       
    /**
     * Presentation threads synchronizer object attribute
     */
    protected static final String LOGIN_PSYNC =
        "com.sun.web.console.login.psync";

    /**
     * Presentation state session attribute.
     */
    protected static final String LOGIN_PSTATE =
        "com.sun.web.console.login.pstate";
    
    
    /** Creates a new instance of LoginConstants */
    public LoginConstants() {
    }
    
}
