
package com.sun.webui.jsf.component;

import javax.el.ELException;
import javax.el.MethodExpression;
import javax.el.ValueExpression;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.faces.component.StateHolder;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.webapp.UIComponentELTag;
import javax.faces.context.FacesContext;

/**
 * This file was generated automatically on Mar 20, 2008.
 */

public class HeadTag extends UIComponentELTag {
    
    /**
     * Returns the requested component type.
     */
    public String getComponentType() {
        return "com.sun.webui.jsf.Head";
    }
    
    /**
     * Returns the requested renderer type.
     */
    public String getRendererType() {
        return "com.sun.webui.jsf.Head";
    }
    
    /**
     * Release any allocated tag handler attributes.
     */
    public void release() {
        super.release();
        dijitAll = null;
        title = null;
        styleSheet = null;
        rendered = null;
        javaScript = null;
        profile = null;
        jsfx = null;
        meta = null;
        debug = null;
        parseOnLoad = null;
        webuiAll = null;
        webuiJsfx = null;
        webuiOnLoad = null;
        defaultBase = null;
    }
    
    /**
     * Transfer tag attribute values to component properties.
     */
    protected void setProperties(UIComponent component) {
        super.setProperties(component);
                        
        if (dijitAll != null) {
            component.setValueExpression("dijitAll", dijitAll);
        }
        if (title != null) {
            component.setValueExpression("title", title);
        }
        if (styleSheet != null) {
            component.setValueExpression("styleSheet", styleSheet);
        }
        if (rendered != null) {
            component.setValueExpression("rendered", rendered);
        }
        if (javaScript != null) {
            component.setValueExpression("javaScript", javaScript);
        }
        if (profile != null) {
            component.setValueExpression("profile", profile);
        }
        if (jsfx != null) {
            component.setValueExpression("jsfx", jsfx);
        }
        if (meta != null) {
            component.setValueExpression("meta", meta);
        }
        if (debug != null) {
            component.setValueExpression("debug", debug);
        }
        if (parseOnLoad != null) {
            component.setValueExpression("parseOnLoad", parseOnLoad);
        }
        if (webuiAll != null) {
            component.setValueExpression("webuiAll", webuiAll);
        }
        if (webuiJsfx != null) {
            component.setValueExpression("webuiJsfx", webuiJsfx);
        }
        if (webuiOnLoad != null) {
            component.setValueExpression("webuiOnLoad", webuiOnLoad);
        }
        if (defaultBase != null) {
            component.setValueExpression("defaultBase", defaultBase);
        }
     }
    

    /**
     * Set attribute corresponding to the "dijitAll" property
     */
    private ValueExpression dijitAll = null;
    public void setDijitAll (ValueExpression dijitAll) {
        this.dijitAll = dijitAll;
    }
     /**
     * Set attribute corresponding to the "title" property
     */
    private ValueExpression title = null;
    public void setTitle (ValueExpression title) {
        this.title = title;
    }
     /**
     * Set attribute corresponding to the "styleSheet" property
     */
    private ValueExpression styleSheet = null;
    public void setStyleSheet (ValueExpression styleSheet) {
        this.styleSheet = styleSheet;
    }
     /**
     * Set attribute corresponding to the "rendered" property
     */
    private ValueExpression rendered = null;
    public void setRendered (ValueExpression rendered) {
        this.rendered = rendered;
    }
     /**
     * Set attribute corresponding to the "javaScript" property
     */
    private ValueExpression javaScript = null;
    public void setJavaScript (ValueExpression javaScript) {
        this.javaScript = javaScript;
    }
     /**
     * Set attribute corresponding to the "profile" property
     */
    private ValueExpression profile = null;
    public void setProfile (ValueExpression profile) {
        this.profile = profile;
    }
      /**
     * Set attribute corresponding to the "jsfx" property
     */
    private ValueExpression jsfx = null;
    public void setJsfx (ValueExpression jsfx) {
        this.jsfx = jsfx;
    }
     /**
     * Set attribute corresponding to the "meta" property
     */
    private ValueExpression meta = null;
    public void setMeta (ValueExpression meta) {
        this.meta = meta;
    }
     /**
     * Set attribute corresponding to the "debug" property
     */
    private ValueExpression debug = null;
    public void setDebug (ValueExpression debug) {
        this.debug = debug;
    }
     /**
     * Set attribute corresponding to the "parseOnLoad" property
     */
    private ValueExpression parseOnLoad = null;
    public void setParseOnLoad (ValueExpression parseOnLoad) {
        this.parseOnLoad = parseOnLoad;
    }
     /**
     * Set attribute corresponding to the "webuiAll" property
     */
    private ValueExpression webuiAll = null;
    public void setWebuiAll (ValueExpression webuiAll) {
        this.webuiAll = webuiAll;
    }
     /**
     * Set attribute corresponding to the "webuiJsfx" property
     */
    private ValueExpression webuiJsfx = null;
    public void setWebuiJsfx (ValueExpression webuiJsfx) {
        this.webuiJsfx = webuiJsfx;
    }
     /**
     * Set attribute corresponding to the "webuiOnLoad" property
     */
    private ValueExpression webuiOnLoad = null;
    public void setWebuiOnLoad (ValueExpression webuiOnLoad) {
        this.webuiOnLoad = webuiOnLoad;
    }
     /**
     * Set attribute corresponding to the "defaultBase" property
     */
    private ValueExpression defaultBase = null;
    public void setDefaultBase (ValueExpression defaultBase) {
        this.defaultBase = defaultBase;
    }
  
}
