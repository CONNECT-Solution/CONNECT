
package com.sun.webui.jsf.component;

import javax.el.ELException;
import javax.el.MethodExpression;
import javax.el.ValueExpression;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.faces.component.StateHolder;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.webapp.UIComponentELTag;
import javax.faces.context.FacesContext;

/**
 * This file was generated automatically on Mar 20, 2008.
 */

public class MenuTag extends UIComponentELTag {
    
    /**
     * Returns the requested component type.
     */
    public String getComponentType() {
        return "com.sun.webui.jsf.Menu";
    }
    
    /**
     * Returns the requested renderer type.
     */
    public String getRendererType() {
        return "com.sun.webui.jsf.widget.Menu";
    }
    
    /**
     * Release any allocated tag handler attributes.
     */
    public void release() {
        super.release();
        immediate = null;
        phaseId = null;
        eventListenerExpression = null;
        eventExpression = null;
        submitForm = null;
        onMouseDown = null;
        onDblClick = null;
        onKeyPress = null;
        onMouseOut = null;
        rendered = null;
        onMouseOver = null;
        htmlTemplate = null;
        onKeyUp = null;
        onMouseMove = null;
        onMouseUp = null;
        styleClass = null;
        items = null;
        onChange = null;
        style = null;
        visible = null;
        onKeyDown = null;
        onClick = null;
    }
    
    /**
     * Transfer tag attribute values to component properties.
     */
    protected void setProperties(UIComponent component) {
        super.setProperties(component);
                        
        if (immediate != null) {
            component.setValueExpression("immediate", immediate);
        }
        if (phaseId != null) {
            component.setValueExpression("phaseId", phaseId);
        }
        if (eventListenerExpression != null) {
            try {
                component.getAttributes().put("eventListenerExpression", eventListenerExpression);
            } catch (ELException e) {
                throw new FacesException(e);
            }
        }
        if (eventExpression != null) {
            try {
                component.getAttributes().put("eventExpression", eventExpression);
            } catch (ELException e) {
                throw new FacesException(e);
            }
        }
        if (submitForm != null) {
            component.setValueExpression("submitForm", submitForm);
        }
        if (onMouseDown != null) {
            component.setValueExpression("onMouseDown", onMouseDown);
        }
        if (onDblClick != null) {
            component.setValueExpression("onDblClick", onDblClick);
        }
        if (onKeyPress != null) {
            component.setValueExpression("onKeyPress", onKeyPress);
        }
        if (onMouseOut != null) {
            component.setValueExpression("onMouseOut", onMouseOut);
        }
        if (rendered != null) {
            component.setValueExpression("rendered", rendered);
        }
        if (onMouseOver != null) {
            component.setValueExpression("onMouseOver", onMouseOver);
        }
        if (htmlTemplate != null) {
            component.setValueExpression("htmlTemplate", htmlTemplate);
        }
        if (onKeyUp != null) {
            component.setValueExpression("onKeyUp", onKeyUp);
        }
        if (onMouseMove != null) {
            component.setValueExpression("onMouseMove", onMouseMove);
        }
        if (onMouseUp != null) {
            component.setValueExpression("onMouseUp", onMouseUp);
        }
        if (styleClass != null) {
            component.setValueExpression("styleClass", styleClass);
        }
        if (items != null) {
            component.setValueExpression("items", items);
        }
        if (onChange != null) {
            component.setValueExpression("onChange", onChange);
        }
        if (style != null) {
            component.setValueExpression("style", style);
        }
        if (visible != null) {
            component.setValueExpression("visible", visible);
        }
        if (onKeyDown != null) {
            component.setValueExpression("onKeyDown", onKeyDown);
        }
        if (onClick != null) {
            component.setValueExpression("onClick", onClick);
        }
     }
    

    /**
     * Set attribute corresponding to the "immediate" property
     */
    private ValueExpression immediate = null;
    public void setImmediate (ValueExpression immediate) {
        this.immediate = immediate;
    }
     /**
     * Set attribute corresponding to the "phaseId" property
     */
    private ValueExpression phaseId = null;
    public void setPhaseId (ValueExpression phaseId) {
        this.phaseId = phaseId;
    }
     /**
     * Set attribute corresponding to the "eventListenerExpression" property
     */
    private MethodExpression eventListenerExpression = null;
    public void setEventListenerExpression (MethodExpression eventListenerExpression) {
        this.eventListenerExpression = eventListenerExpression;
    }
     /**
     * Set attribute corresponding to the "eventExpression" property
     */
    private MethodExpression eventExpression = null;
    public void setEventExpression (MethodExpression eventExpression) {
        this.eventExpression = eventExpression;
    }
     /**
     * Set attribute corresponding to the "submitForm" property
     */
    private ValueExpression submitForm = null;
    public void setSubmitForm (ValueExpression submitForm) {
        this.submitForm = submitForm;
    }
     /**
     * Set attribute corresponding to the "onMouseDown" property
     */
    private ValueExpression onMouseDown = null;
    public void setOnMouseDown (ValueExpression onMouseDown) {
        this.onMouseDown = onMouseDown;
    }
     /**
     * Set attribute corresponding to the "onDblClick" property
     */
    private ValueExpression onDblClick = null;
    public void setOnDblClick (ValueExpression onDblClick) {
        this.onDblClick = onDblClick;
    }
     /**
     * Set attribute corresponding to the "onKeyPress" property
     */
    private ValueExpression onKeyPress = null;
    public void setOnKeyPress (ValueExpression onKeyPress) {
        this.onKeyPress = onKeyPress;
    }
     /**
     * Set attribute corresponding to the "onMouseOut" property
     */
    private ValueExpression onMouseOut = null;
    public void setOnMouseOut (ValueExpression onMouseOut) {
        this.onMouseOut = onMouseOut;
    }
     /**
     * Set attribute corresponding to the "rendered" property
     */
    private ValueExpression rendered = null;
    public void setRendered (ValueExpression rendered) {
        this.rendered = rendered;
    }
      /**
     * Set attribute corresponding to the "onMouseOver" property
     */
    private ValueExpression onMouseOver = null;
    public void setOnMouseOver (ValueExpression onMouseOver) {
        this.onMouseOver = onMouseOver;
    }
     /**
     * Set attribute corresponding to the "htmlTemplate" property
     */
    private ValueExpression htmlTemplate = null;
    public void setHtmlTemplate (ValueExpression htmlTemplate) {
        this.htmlTemplate = htmlTemplate;
    }
     /**
     * Set attribute corresponding to the "onKeyUp" property
     */
    private ValueExpression onKeyUp = null;
    public void setOnKeyUp (ValueExpression onKeyUp) {
        this.onKeyUp = onKeyUp;
    }
     /**
     * Set attribute corresponding to the "onMouseMove" property
     */
    private ValueExpression onMouseMove = null;
    public void setOnMouseMove (ValueExpression onMouseMove) {
        this.onMouseMove = onMouseMove;
    }
     /**
     * Set attribute corresponding to the "onMouseUp" property
     */
    private ValueExpression onMouseUp = null;
    public void setOnMouseUp (ValueExpression onMouseUp) {
        this.onMouseUp = onMouseUp;
    }
     /**
     * Set attribute corresponding to the "styleClass" property
     */
    private ValueExpression styleClass = null;
    public void setStyleClass (ValueExpression styleClass) {
        this.styleClass = styleClass;
    }
     /**
     * Set attribute corresponding to the "items" property
     */
    private ValueExpression items = null;
    public void setItems (ValueExpression items) {
        this.items = items;
    }
     /**
     * Set attribute corresponding to the "onChange" property
     */
    private ValueExpression onChange = null;
    public void setOnChange (ValueExpression onChange) {
        this.onChange = onChange;
    }
     /**
     * Set attribute corresponding to the "style" property
     */
    private ValueExpression style = null;
    public void setStyle (ValueExpression style) {
        this.style = style;
    }
     /**
     * Set attribute corresponding to the "visible" property
     */
    private ValueExpression visible = null;
    public void setVisible (ValueExpression visible) {
        this.visible = visible;
    }
     /**
     * Set attribute corresponding to the "onKeyDown" property
     */
    private ValueExpression onKeyDown = null;
    public void setOnKeyDown (ValueExpression onKeyDown) {
        this.onKeyDown = onKeyDown;
    }
     /**
     * Set attribute corresponding to the "onClick" property
     */
    private ValueExpression onClick = null;
    public void setOnClick (ValueExpression onClick) {
        this.onClick = onClick;
    }
  
}
