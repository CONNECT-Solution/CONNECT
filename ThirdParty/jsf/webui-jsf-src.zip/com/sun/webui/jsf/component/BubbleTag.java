
package com.sun.webui.jsf.component;

import javax.el.ELException;
import javax.el.MethodExpression;
import javax.el.ValueExpression;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.faces.component.StateHolder;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.webapp.UIComponentELTag;
import javax.faces.context.FacesContext;

/**
 * This file was generated automatically on Mar 20, 2008.
 */

public class BubbleTag extends UIComponentELTag {
    
    /**
     * Returns the requested component type.
     */
    public String getComponentType() {
        return "com.sun.webui.jsf.Bubble";
    }
    
    /**
     * Returns the requested renderer type.
     */
    public String getRendererType() {
        return "com.sun.webui.jsf.widget.Bubble";
    }
    
    /**
     * Release any allocated tag handler attributes.
     */
    public void release() {
        super.release();
        rendered = null;
        focusId = null;
        width = null;
        title = null;
        htmlTemplate = null;
        styleClass = null;
        openDelay = null;
        style = null;
        visible = null;
        autoClose = null;
        closeButton = null;
        tabIndex = null;
        duration = null;
    }
    
    /**
     * Transfer tag attribute values to component properties.
     */
    protected void setProperties(UIComponent component) {
        super.setProperties(component);
                        
        if (rendered != null) {
            component.setValueExpression("rendered", rendered);
        }
        if (focusId != null) {
            component.setValueExpression("focusId", focusId);
        }
        if (width != null) {
            component.setValueExpression("width", width);
        }
        if (title != null) {
            component.setValueExpression("title", title);
        }
        if (htmlTemplate != null) {
            component.setValueExpression("htmlTemplate", htmlTemplate);
        }
        if (styleClass != null) {
            component.setValueExpression("styleClass", styleClass);
        }
        if (openDelay != null) {
            component.setValueExpression("openDelay", openDelay);
        }
        if (style != null) {
            component.setValueExpression("style", style);
        }
        if (visible != null) {
            component.setValueExpression("visible", visible);
        }
        if (autoClose != null) {
            component.setValueExpression("autoClose", autoClose);
        }
        if (closeButton != null) {
            component.setValueExpression("closeButton", closeButton);
        }
        if (tabIndex != null) {
            component.setValueExpression("tabIndex", tabIndex);
        }
        if (duration != null) {
            component.setValueExpression("duration", duration);
        }
     }
    

    /**
     * Set attribute corresponding to the "rendered" property
     */
    private ValueExpression rendered = null;
    public void setRendered (ValueExpression rendered) {
        this.rendered = rendered;
    }
      /**
     * Set attribute corresponding to the "focusId" property
     */
    private ValueExpression focusId = null;
    public void setFocusId (ValueExpression focusId) {
        this.focusId = focusId;
    }
      /**
     * Set attribute corresponding to the "width" property
     */
    private ValueExpression width = null;
    public void setWidth (ValueExpression width) {
        this.width = width;
    }
      /**
     * Set attribute corresponding to the "title" property
     */
    private ValueExpression title = null;
    public void setTitle (ValueExpression title) {
        this.title = title;
    }
     /**
     * Set attribute corresponding to the "htmlTemplate" property
     */
    private ValueExpression htmlTemplate = null;
    public void setHtmlTemplate (ValueExpression htmlTemplate) {
        this.htmlTemplate = htmlTemplate;
    }
     /**
     * Set attribute corresponding to the "styleClass" property
     */
    private ValueExpression styleClass = null;
    public void setStyleClass (ValueExpression styleClass) {
        this.styleClass = styleClass;
    }
     /**
     * Set attribute corresponding to the "openDelay" property
     */
    private ValueExpression openDelay = null;
    public void setOpenDelay (ValueExpression openDelay) {
        this.openDelay = openDelay;
    }
     /**
     * Set attribute corresponding to the "style" property
     */
    private ValueExpression style = null;
    public void setStyle (ValueExpression style) {
        this.style = style;
    }
     /**
     * Set attribute corresponding to the "visible" property
     */
    private ValueExpression visible = null;
    public void setVisible (ValueExpression visible) {
        this.visible = visible;
    }
     /**
     * Set attribute corresponding to the "autoClose" property
     */
    private ValueExpression autoClose = null;
    public void setAutoClose (ValueExpression autoClose) {
        this.autoClose = autoClose;
    }
     /**
     * Set attribute corresponding to the "closeButton" property
     */
    private ValueExpression closeButton = null;
    public void setCloseButton (ValueExpression closeButton) {
        this.closeButton = closeButton;
    }
     /**
     * Set attribute corresponding to the "tabIndex" property
     */
    private ValueExpression tabIndex = null;
    public void setTabIndex (ValueExpression tabIndex) {
        this.tabIndex = tabIndex;
    }
     /**
     * Set attribute corresponding to the "duration" property
     */
    private ValueExpression duration = null;
    public void setDuration (ValueExpression duration) {
        this.duration = duration;
    }
  
}
