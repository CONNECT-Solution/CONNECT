
package com.sun.webui.jsf.component;

import javax.el.ELException;
import javax.el.MethodExpression;
import javax.el.ValueExpression;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.faces.component.StateHolder;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.webapp.UIComponentELTag;
import javax.faces.context.FacesContext;

/**
 * This file was generated automatically on Mar 20, 2008.
 */

public class TreeTag extends UIComponentELTag {
    
    /**
     * Returns the requested component type.
     */
    public String getComponentType() {
        return "com.sun.webui.jsf.Tree";
    }
    
    /**
     * Returns the requested renderer type.
     */
    public String getRendererType() {
        return "com.sun.webui.jsf.Tree";
    }
    
    /**
     * Release any allocated tag handler attributes.
     */
    public void release() {
        super.release();
        toolTip = null;
        text = null;
        imageURL = null;
        required = null;
        actionExpression = null;
        clientSide = null;
        target = null;
        rendered = null;
        styleClass = null;
        selected = null;
        immediate = null;
        actionListenerExpression = null;
        expandOnSelect = null;
        style = null;
        visible = null;
        url = null;
    }
    
    /**
     * Transfer tag attribute values to component properties.
     */
    protected void setProperties(UIComponent component) {
        super.setProperties(component);
                        
        if (toolTip != null) {
            component.setValueExpression("toolTip", toolTip);
        }
        if (text != null) {
            component.setValueExpression("text", text);
        }
        if (imageURL != null) {
            component.setValueExpression("imageURL", imageURL);
        }
        if (required != null) {
            component.setValueExpression("required", required);
        }
        if (actionExpression != null) {
            try {
                component.getAttributes().put("actionExpression", actionExpression);
            } catch (ELException e) {
                throw new FacesException(e);
            }
        }
        if (clientSide != null) {
            component.setValueExpression("clientSide", clientSide);
        }
        if (target != null) {
            component.setValueExpression("target", target);
        }
        if (rendered != null) {
            component.setValueExpression("rendered", rendered);
        }
        if (styleClass != null) {
            component.setValueExpression("styleClass", styleClass);
        }
        if (selected != null) {
            component.setValueExpression("selected", selected);
        }
        if (immediate != null) {
            component.setValueExpression("immediate", immediate);
        }
        if (actionListenerExpression != null) {
            try {
                component.getAttributes().put("actionListenerExpression", actionListenerExpression);
            } catch (ELException e) {
                throw new FacesException(e);
            }
        }
        if (expandOnSelect != null) {
            component.setValueExpression("expandOnSelect", expandOnSelect);
        }
        if (style != null) {
            component.setValueExpression("style", style);
        }
        if (visible != null) {
            component.setValueExpression("visible", visible);
        }
        if (url != null) {
            component.setValueExpression("url", url);
        }
     }
    

    /**
     * Set attribute corresponding to the "toolTip" property
     */
    private ValueExpression toolTip = null;
    public void setToolTip (ValueExpression toolTip) {
        this.toolTip = toolTip;
    }
     /**
     * Set attribute corresponding to the "text" property
     */
    private ValueExpression text = null;
    public void setText (ValueExpression text) {
        this.text = text;
    }
     /**
     * Set attribute corresponding to the "imageURL" property
     */
    private ValueExpression imageURL = null;
    public void setImageURL (ValueExpression imageURL) {
        this.imageURL = imageURL;
    }
     /**
     * Set attribute corresponding to the "required" property
     */
    private ValueExpression required = null;
    public void setRequired (ValueExpression required) {
        this.required = required;
    }
     /**
     * Set attribute corresponding to the "actionExpression" property
     */
    private MethodExpression actionExpression = null;
    public void setActionExpression (MethodExpression actionExpression) {
        this.actionExpression = actionExpression;
    }
     /**
     * Set attribute corresponding to the "clientSide" property
     */
    private ValueExpression clientSide = null;
    public void setClientSide (ValueExpression clientSide) {
        this.clientSide = clientSide;
    }
     /**
     * Set attribute corresponding to the "target" property
     */
    private ValueExpression target = null;
    public void setTarget (ValueExpression target) {
        this.target = target;
    }
     /**
     * Set attribute corresponding to the "rendered" property
     */
    private ValueExpression rendered = null;
    public void setRendered (ValueExpression rendered) {
        this.rendered = rendered;
    }
      /**
     * Set attribute corresponding to the "styleClass" property
     */
    private ValueExpression styleClass = null;
    public void setStyleClass (ValueExpression styleClass) {
        this.styleClass = styleClass;
    }
     /**
     * Set attribute corresponding to the "selected" property
     */
    private ValueExpression selected = null;
    public void setSelected (ValueExpression selected) {
        this.selected = selected;
    }
     /**
     * Set attribute corresponding to the "immediate" property
     */
    private ValueExpression immediate = null;
    public void setImmediate (ValueExpression immediate) {
        this.immediate = immediate;
    }
     /**
     * Set attribute corresponding to the "actionListenerExpression" property
     */
    private MethodExpression actionListenerExpression = null;
    public void setActionListenerExpression (MethodExpression actionListenerExpression) {
        this.actionListenerExpression = actionListenerExpression;
    }
      /**
     * Set attribute corresponding to the "expandOnSelect" property
     */
    private ValueExpression expandOnSelect = null;
    public void setExpandOnSelect (ValueExpression expandOnSelect) {
        this.expandOnSelect = expandOnSelect;
    }
     /**
     * Set attribute corresponding to the "style" property
     */
    private ValueExpression style = null;
    public void setStyle (ValueExpression style) {
        this.style = style;
    }
     /**
     * Set attribute corresponding to the "visible" property
     */
    private ValueExpression visible = null;
    public void setVisible (ValueExpression visible) {
        this.visible = visible;
    }
     /**
     * Set attribute corresponding to the "url" property
     */
    private ValueExpression url = null;
    public void setUrl (ValueExpression url) {
        this.url = url;
    }
  
}
