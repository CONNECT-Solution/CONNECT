
package com.sun.webui.jsf.component;

import javax.el.ELException;
import javax.el.MethodExpression;
import javax.el.ValueExpression;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.faces.component.StateHolder;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.webapp.UIComponentELTag;
import javax.faces.context.FacesContext;

/**
 * This file was generated automatically on Mar 20, 2008.
 */

public class AccordionTabTag extends UIComponentELTag {
    
    /**
     * Returns the requested component type.
     */
    public String getComponentType() {
        return "com.sun.webui.jsf.AccordionTab";
    }
    
    /**
     * Returns the requested renderer type.
     */
    public String getRendererType() {
        return "com.sun.webui.jsf.widget.AccordionTab";
    }
    
    /**
     * Release any allocated tag handler attributes.
     */
    public void release() {
        super.release();
        htmlTemplate = null;
        styleClass = null;
        selected = null;
        title = null;
        style = null;
        visible = null;
        rendered = null;
        focusId = null;
        multipleSelect = null;
        contentHeight = null;
    }
    
    /**
     * Transfer tag attribute values to component properties.
     */
    protected void setProperties(UIComponent component) {
        super.setProperties(component);
                        
        if (htmlTemplate != null) {
            component.setValueExpression("htmlTemplate", htmlTemplate);
        }
        if (styleClass != null) {
            component.setValueExpression("styleClass", styleClass);
        }
        if (selected != null) {
            component.setValueExpression("selected", selected);
        }
        if (title != null) {
            component.setValueExpression("title", title);
        }
        if (style != null) {
            component.setValueExpression("style", style);
        }
        if (visible != null) {
            component.setValueExpression("visible", visible);
        }
        if (rendered != null) {
            component.setValueExpression("rendered", rendered);
        }
        if (focusId != null) {
            component.setValueExpression("focusId", focusId);
        }
        if (multipleSelect != null) {
            component.setValueExpression("multipleSelect", multipleSelect);
        }
        if (contentHeight != null) {
            component.setValueExpression("contentHeight", contentHeight);
        }
     }
    

    /**
     * Set attribute corresponding to the "htmlTemplate" property
     */
    private ValueExpression htmlTemplate = null;
    public void setHtmlTemplate (ValueExpression htmlTemplate) {
        this.htmlTemplate = htmlTemplate;
    }
     /**
     * Set attribute corresponding to the "styleClass" property
     */
    private ValueExpression styleClass = null;
    public void setStyleClass (ValueExpression styleClass) {
        this.styleClass = styleClass;
    }
     /**
     * Set attribute corresponding to the "selected" property
     */
    private ValueExpression selected = null;
    public void setSelected (ValueExpression selected) {
        this.selected = selected;
    }
     /**
     * Set attribute corresponding to the "title" property
     */
    private ValueExpression title = null;
    public void setTitle (ValueExpression title) {
        this.title = title;
    }
     /**
     * Set attribute corresponding to the "style" property
     */
    private ValueExpression style = null;
    public void setStyle (ValueExpression style) {
        this.style = style;
    }
     /**
     * Set attribute corresponding to the "visible" property
     */
    private ValueExpression visible = null;
    public void setVisible (ValueExpression visible) {
        this.visible = visible;
    }
     /**
     * Set attribute corresponding to the "rendered" property
     */
    private ValueExpression rendered = null;
    public void setRendered (ValueExpression rendered) {
        this.rendered = rendered;
    }
      /**
     * Set attribute corresponding to the "focusId" property
     */
    private ValueExpression focusId = null;
    public void setFocusId (ValueExpression focusId) {
        this.focusId = focusId;
    }
     /**
     * Set attribute corresponding to the "multipleSelect" property
     */
    private ValueExpression multipleSelect = null;
    public void setMultipleSelect (ValueExpression multipleSelect) {
        this.multipleSelect = multipleSelect;
    }
     /**
     * Set attribute corresponding to the "contentHeight" property
     */
    private ValueExpression contentHeight = null;
    public void setContentHeight (ValueExpression contentHeight) {
        this.contentHeight = contentHeight;
    }
  
}
