
package com.sun.webui.jsf.component;

import javax.el.ELException;
import javax.el.MethodExpression;
import javax.el.ValueExpression;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.faces.component.StateHolder;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.webapp.UIComponentELTag;
import javax.faces.context.FacesContext;

/**
 * This file was generated automatically on Mar 20, 2008.
 */

public class DndContainerTag extends UIComponentELTag {
    
    /**
     * Returns the requested component type.
     */
    public String getComponentType() {
        return "com.sun.webui.jsf.DndContainer";
    }
    
    /**
     * Returns the requested renderer type.
     */
    public String getRendererType() {
        return "com.sun.webui.jsf.widget.DndContainer";
    }
    
    /**
     * Release any allocated tag handler attributes.
     */
    public void release() {
        super.release();
        rendered = null;
        onDropFunc = null;
        onNodeCreateFunc = null;
        dragTypes = null;
        styleClass = null;
        horizontalIndicator = null;
        dropTypes = null;
        visible = null;
        style = null;
        copyOnly = null;
    }
    
    /**
     * Transfer tag attribute values to component properties.
     */
    protected void setProperties(UIComponent component) {
        super.setProperties(component);
                        
        if (rendered != null) {
            component.setValueExpression("rendered", rendered);
        }
        if (onDropFunc != null) {
            component.setValueExpression("onDropFunc", onDropFunc);
        }
        if (onNodeCreateFunc != null) {
            component.setValueExpression("onNodeCreateFunc", onNodeCreateFunc);
        }
        if (dragTypes != null) {
            component.setValueExpression("dragTypes", dragTypes);
        }
        if (styleClass != null) {
            component.setValueExpression("styleClass", styleClass);
        }
        if (horizontalIndicator != null) {
            component.setValueExpression("horizontalIndicator", horizontalIndicator);
        }
        if (dropTypes != null) {
            component.setValueExpression("dropTypes", dropTypes);
        }
        if (visible != null) {
            component.setValueExpression("visible", visible);
        }
        if (style != null) {
            component.setValueExpression("style", style);
        }
        if (copyOnly != null) {
            component.setValueExpression("copyOnly", copyOnly);
        }
     }
    

    /**
     * Set attribute corresponding to the "rendered" property
     */
    private ValueExpression rendered = null;
    public void setRendered (ValueExpression rendered) {
        this.rendered = rendered;
    }
      /**
     * Set attribute corresponding to the "onDropFunc" property
     */
    private ValueExpression onDropFunc = null;
    public void setOnDropFunc (ValueExpression onDropFunc) {
        this.onDropFunc = onDropFunc;
    }
     /**
     * Set attribute corresponding to the "onNodeCreateFunc" property
     */
    private ValueExpression onNodeCreateFunc = null;
    public void setOnNodeCreateFunc (ValueExpression onNodeCreateFunc) {
        this.onNodeCreateFunc = onNodeCreateFunc;
    }
     /**
     * Set attribute corresponding to the "dragTypes" property
     */
    private ValueExpression dragTypes = null;
    public void setDragTypes (ValueExpression dragTypes) {
        this.dragTypes = dragTypes;
    }
     /**
     * Set attribute corresponding to the "styleClass" property
     */
    private ValueExpression styleClass = null;
    public void setStyleClass (ValueExpression styleClass) {
        this.styleClass = styleClass;
    }
     /**
     * Set attribute corresponding to the "horizontalIndicator" property
     */
    private ValueExpression horizontalIndicator = null;
    public void setHorizontalIndicator (ValueExpression horizontalIndicator) {
        this.horizontalIndicator = horizontalIndicator;
    }
     /**
     * Set attribute corresponding to the "dropTypes" property
     */
    private ValueExpression dropTypes = null;
    public void setDropTypes (ValueExpression dropTypes) {
        this.dropTypes = dropTypes;
    }
     /**
     * Set attribute corresponding to the "visible" property
     */
    private ValueExpression visible = null;
    public void setVisible (ValueExpression visible) {
        this.visible = visible;
    }
     /**
     * Set attribute corresponding to the "style" property
     */
    private ValueExpression style = null;
    public void setStyle (ValueExpression style) {
        this.style = style;
    }
     /**
     * Set attribute corresponding to the "copyOnly" property
     */
    private ValueExpression copyOnly = null;
    public void setCopyOnly (ValueExpression copyOnly) {
        this.copyOnly = copyOnly;
    }
  
}
