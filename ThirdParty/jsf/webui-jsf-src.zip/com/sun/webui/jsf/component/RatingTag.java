
package com.sun.webui.jsf.component;

import javax.el.ELException;
import javax.el.MethodExpression;
import javax.el.ValueExpression;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.faces.component.StateHolder;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.webapp.UIComponentELTag;
import javax.faces.context.FacesContext;

/**
 * This file was generated automatically on Mar 20, 2008.
 */

public class RatingTag extends UIComponentELTag {
    
    /**
     * Returns the requested component type.
     */
    public String getComponentType() {
        return "com.sun.webui.jsf.Rating";
    }
    
    /**
     * Returns the requested renderer type.
     */
    public String getRendererType() {
        return "com.sun.webui.jsf.widget.Rating";
    }
    
    /**
     * Release any allocated tag handler attributes.
     */
    public void release() {
        super.release();
        converter = null;
        required = null;
        immediate = null;
        validatorExpression = null;
        rendered = null;
        valueChangeListenerExpression = null;
        notInterestedAcknowledgedText = null;
        averageGrade = null;
        modeToggleAcknowledgedTexts = null;
        maxGrade = null;
        clearHoverText = null;
        inAverageMode = null;
        includeText = null;
        clearAcknowledgedText = null;
        modeReadOnly = null;
        grade = null;
        gradeReadOnly = null;
        notInterestedHoverText = null;
        autoSubmit = null;
        styleClass = null;
        gradeAcknowledgedText = null;
        gradeHoverTexts = null;
        style = null;
        visible = null;
        modeToggleHoverTexts = null;
        includeNotInterested = null;
        includeClear = null;
        tabIndex = null;
        includeModeToggle = null;
    }
    
    /**
     * Transfer tag attribute values to component properties.
     */
    protected void setProperties(UIComponent component) {
        super.setProperties(component);
                        
        if (converter != null) {
            component.setValueExpression("converter", converter);
        }
        if (required != null) {
            component.setValueExpression("required", required);
        }
        if (immediate != null) {
            component.setValueExpression("immediate", immediate);
        }
        if (validatorExpression != null) {
            try {
                component.getAttributes().put("validatorExpression", validatorExpression);
            } catch (ELException e) {
                throw new FacesException(e);
            }
        }
        if (rendered != null) {
            component.setValueExpression("rendered", rendered);
        }
        if (valueChangeListenerExpression != null) {
            try {
                component.getAttributes().put("valueChangeListenerExpression", valueChangeListenerExpression);
            } catch (ELException e) {
                throw new FacesException(e);
            }
        }
        if (notInterestedAcknowledgedText != null) {
            component.setValueExpression("notInterestedAcknowledgedText", notInterestedAcknowledgedText);
        }
        if (averageGrade != null) {
            component.setValueExpression("averageGrade", averageGrade);
        }
        if (modeToggleAcknowledgedTexts != null) {
            component.setValueExpression("modeToggleAcknowledgedTexts", modeToggleAcknowledgedTexts);
        }
        if (maxGrade != null) {
            component.setValueExpression("maxGrade", maxGrade);
        }
        if (clearHoverText != null) {
            component.setValueExpression("clearHoverText", clearHoverText);
        }
        if (inAverageMode != null) {
            component.setValueExpression("inAverageMode", inAverageMode);
        }
        if (includeText != null) {
            component.setValueExpression("includeText", includeText);
        }
        if (clearAcknowledgedText != null) {
            component.setValueExpression("clearAcknowledgedText", clearAcknowledgedText);
        }
        if (modeReadOnly != null) {
            component.setValueExpression("modeReadOnly", modeReadOnly);
        }
        if (grade != null) {
            component.setValueExpression("grade", grade);
        }
        if (gradeReadOnly != null) {
            component.setValueExpression("gradeReadOnly", gradeReadOnly);
        }
        if (notInterestedHoverText != null) {
            component.setValueExpression("notInterestedHoverText", notInterestedHoverText);
        }
        if (autoSubmit != null) {
            component.setValueExpression("autoSubmit", autoSubmit);
        }
        if (styleClass != null) {
            component.setValueExpression("styleClass", styleClass);
        }
        if (gradeAcknowledgedText != null) {
            component.setValueExpression("gradeAcknowledgedText", gradeAcknowledgedText);
        }
        if (gradeHoverTexts != null) {
            component.setValueExpression("gradeHoverTexts", gradeHoverTexts);
        }
        if (style != null) {
            component.setValueExpression("style", style);
        }
        if (visible != null) {
            component.setValueExpression("visible", visible);
        }
        if (modeToggleHoverTexts != null) {
            component.setValueExpression("modeToggleHoverTexts", modeToggleHoverTexts);
        }
        if (includeNotInterested != null) {
            component.setValueExpression("includeNotInterested", includeNotInterested);
        }
        if (includeClear != null) {
            component.setValueExpression("includeClear", includeClear);
        }
        if (tabIndex != null) {
            component.setValueExpression("tabIndex", tabIndex);
        }
        if (includeModeToggle != null) {
            component.setValueExpression("includeModeToggle", includeModeToggle);
        }
     }
    

      /**
     * Set attribute corresponding to the "converter" property
     */
    private ValueExpression converter = null;
    public void setConverter (ValueExpression converter) {
        this.converter = converter;
    }
     /**
     * Set attribute corresponding to the "required" property
     */
    private ValueExpression required = null;
    public void setRequired (ValueExpression required) {
        this.required = required;
    }
     /**
     * Set attribute corresponding to the "immediate" property
     */
    private ValueExpression immediate = null;
    public void setImmediate (ValueExpression immediate) {
        this.immediate = immediate;
    }
     /**
     * Set attribute corresponding to the "validatorExpression" property
     */
    private MethodExpression validatorExpression = null;
    public void setValidatorExpression (MethodExpression validatorExpression) {
        this.validatorExpression = validatorExpression;
    }
     /**
     * Set attribute corresponding to the "rendered" property
     */
    private ValueExpression rendered = null;
    public void setRendered (ValueExpression rendered) {
        this.rendered = rendered;
    }
      /**
     * Set attribute corresponding to the "valueChangeListenerExpression" property
     */
    private MethodExpression valueChangeListenerExpression = null;
    public void setValueChangeListenerExpression (MethodExpression valueChangeListenerExpression) {
        this.valueChangeListenerExpression = valueChangeListenerExpression;
    }
       /**
     * Set attribute corresponding to the "notInterestedAcknowledgedText" property
     */
    private ValueExpression notInterestedAcknowledgedText = null;
    public void setNotInterestedAcknowledgedText (ValueExpression notInterestedAcknowledgedText) {
        this.notInterestedAcknowledgedText = notInterestedAcknowledgedText;
    }
      /**
     * Set attribute corresponding to the "averageGrade" property
     */
    private ValueExpression averageGrade = null;
    public void setAverageGrade (ValueExpression averageGrade) {
        this.averageGrade = averageGrade;
    }
     /**
     * Set attribute corresponding to the "modeToggleAcknowledgedTexts" property
     */
    private ValueExpression modeToggleAcknowledgedTexts = null;
    public void setModeToggleAcknowledgedTexts (ValueExpression modeToggleAcknowledgedTexts) {
        this.modeToggleAcknowledgedTexts = modeToggleAcknowledgedTexts;
    }
     /**
     * Set attribute corresponding to the "maxGrade" property
     */
    private ValueExpression maxGrade = null;
    public void setMaxGrade (ValueExpression maxGrade) {
        this.maxGrade = maxGrade;
    }
     /**
     * Set attribute corresponding to the "clearHoverText" property
     */
    private ValueExpression clearHoverText = null;
    public void setClearHoverText (ValueExpression clearHoverText) {
        this.clearHoverText = clearHoverText;
    }
     /**
     * Set attribute corresponding to the "inAverageMode" property
     */
    private ValueExpression inAverageMode = null;
    public void setInAverageMode (ValueExpression inAverageMode) {
        this.inAverageMode = inAverageMode;
    }
     /**
     * Set attribute corresponding to the "includeText" property
     */
    private ValueExpression includeText = null;
    public void setIncludeText (ValueExpression includeText) {
        this.includeText = includeText;
    }
     /**
     * Set attribute corresponding to the "clearAcknowledgedText" property
     */
    private ValueExpression clearAcknowledgedText = null;
    public void setClearAcknowledgedText (ValueExpression clearAcknowledgedText) {
        this.clearAcknowledgedText = clearAcknowledgedText;
    }
     /**
     * Set attribute corresponding to the "modeReadOnly" property
     */
    private ValueExpression modeReadOnly = null;
    public void setModeReadOnly (ValueExpression modeReadOnly) {
        this.modeReadOnly = modeReadOnly;
    }
     /**
     * Set attribute corresponding to the "grade" property
     */
    private ValueExpression grade = null;
    public void setGrade (ValueExpression grade) {
        this.grade = grade;
    }
     /**
     * Set attribute corresponding to the "gradeReadOnly" property
     */
    private ValueExpression gradeReadOnly = null;
    public void setGradeReadOnly (ValueExpression gradeReadOnly) {
        this.gradeReadOnly = gradeReadOnly;
    }
     /**
     * Set attribute corresponding to the "notInterestedHoverText" property
     */
    private ValueExpression notInterestedHoverText = null;
    public void setNotInterestedHoverText (ValueExpression notInterestedHoverText) {
        this.notInterestedHoverText = notInterestedHoverText;
    }
     /**
     * Set attribute corresponding to the "autoSubmit" property
     */
    private ValueExpression autoSubmit = null;
    public void setAutoSubmit (ValueExpression autoSubmit) {
        this.autoSubmit = autoSubmit;
    }
     /**
     * Set attribute corresponding to the "styleClass" property
     */
    private ValueExpression styleClass = null;
    public void setStyleClass (ValueExpression styleClass) {
        this.styleClass = styleClass;
    }
     /**
     * Set attribute corresponding to the "gradeAcknowledgedText" property
     */
    private ValueExpression gradeAcknowledgedText = null;
    public void setGradeAcknowledgedText (ValueExpression gradeAcknowledgedText) {
        this.gradeAcknowledgedText = gradeAcknowledgedText;
    }
     /**
     * Set attribute corresponding to the "gradeHoverTexts" property
     */
    private ValueExpression gradeHoverTexts = null;
    public void setGradeHoverTexts (ValueExpression gradeHoverTexts) {
        this.gradeHoverTexts = gradeHoverTexts;
    }
     /**
     * Set attribute corresponding to the "style" property
     */
    private ValueExpression style = null;
    public void setStyle (ValueExpression style) {
        this.style = style;
    }
     /**
     * Set attribute corresponding to the "visible" property
     */
    private ValueExpression visible = null;
    public void setVisible (ValueExpression visible) {
        this.visible = visible;
    }
     /**
     * Set attribute corresponding to the "modeToggleHoverTexts" property
     */
    private ValueExpression modeToggleHoverTexts = null;
    public void setModeToggleHoverTexts (ValueExpression modeToggleHoverTexts) {
        this.modeToggleHoverTexts = modeToggleHoverTexts;
    }
     /**
     * Set attribute corresponding to the "includeNotInterested" property
     */
    private ValueExpression includeNotInterested = null;
    public void setIncludeNotInterested (ValueExpression includeNotInterested) {
        this.includeNotInterested = includeNotInterested;
    }
     /**
     * Set attribute corresponding to the "includeClear" property
     */
    private ValueExpression includeClear = null;
    public void setIncludeClear (ValueExpression includeClear) {
        this.includeClear = includeClear;
    }
     /**
     * Set attribute corresponding to the "tabIndex" property
     */
    private ValueExpression tabIndex = null;
    public void setTabIndex (ValueExpression tabIndex) {
        this.tabIndex = tabIndex;
    }
     /**
     * Set attribute corresponding to the "includeModeToggle" property
     */
    private ValueExpression includeModeToggle = null;
    public void setIncludeModeToggle (ValueExpression includeModeToggle) {
        this.includeModeToggle = includeModeToggle;
    }
  
}
