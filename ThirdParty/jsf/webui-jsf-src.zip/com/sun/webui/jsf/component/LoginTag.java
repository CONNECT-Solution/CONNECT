
package com.sun.webui.jsf.component;

import javax.el.ELException;
import javax.el.MethodExpression;
import javax.el.ValueExpression;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.faces.component.StateHolder;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.webapp.UIComponentELTag;
import javax.faces.context.FacesContext;

/**
 * This file was generated automatically on Mar 20, 2008.
 */

public class LoginTag extends UIComponentELTag {
    
    /**
     * Returns the requested component type.
     */
    public String getComponentType() {
        return "com.sun.webui.jsf.Login";
    }
    
    /**
     * Returns the requested renderer type.
     */
    public String getRendererType() {
        return "com.sun.webui.jsf.widget.Login";
    }
    
    /**
     * Release any allocated tag handler attributes.
     */
    public void release() {
        super.release();
        value = null;
        converter = null;
        required = null;
        validatorExpression = null;
        rendered = null;
        valueChangeListenerExpression = null;
        loginController = null;
        htmlTemplate = null;
        styleClass = null;
        immediate = null;
        serviceName = null;
        style = null;
        redirectURL = null;
        tabIndex = null;
        autoStart = null;
    }
    
    /**
     * Transfer tag attribute values to component properties.
     */
    protected void setProperties(UIComponent component) {
        super.setProperties(component);
                        
        if (value != null) {
            component.setValueExpression("value", value);
        }
        if (converter != null) {
            component.setValueExpression("converter", converter);
        }
        if (required != null) {
            component.setValueExpression("required", required);
        }
        if (validatorExpression != null) {
            try {
                component.getAttributes().put("validatorExpression", validatorExpression);
            } catch (ELException e) {
                throw new FacesException(e);
            }
        }
        if (rendered != null) {
            component.setValueExpression("rendered", rendered);
        }
        if (valueChangeListenerExpression != null) {
            try {
                component.getAttributes().put("valueChangeListenerExpression", valueChangeListenerExpression);
            } catch (ELException e) {
                throw new FacesException(e);
            }
        }
        if (loginController != null) {
            component.setValueExpression("loginController", loginController);
        }
        if (htmlTemplate != null) {
            component.setValueExpression("htmlTemplate", htmlTemplate);
        }
        if (styleClass != null) {
            component.setValueExpression("styleClass", styleClass);
        }
        if (immediate != null) {
            component.setValueExpression("immediate", immediate);
        }
        if (serviceName != null) {
            component.setValueExpression("serviceName", serviceName);
        }
        if (style != null) {
            component.setValueExpression("style", style);
        }
        if (redirectURL != null) {
            component.setValueExpression("redirectURL", redirectURL);
        }
        if (tabIndex != null) {
            component.setValueExpression("tabIndex", tabIndex);
        }
        if (autoStart != null) {
            component.setValueExpression("autoStart", autoStart);
        }
     }
    

     /**
     * Set attribute corresponding to the "value" property
     */
    private ValueExpression value = null;
    public void setValue (ValueExpression value) {
        this.value = value;
    }
      /**
     * Set attribute corresponding to the "converter" property
     */
    private ValueExpression converter = null;
    public void setConverter (ValueExpression converter) {
        this.converter = converter;
    }
     /**
     * Set attribute corresponding to the "required" property
     */
    private ValueExpression required = null;
    public void setRequired (ValueExpression required) {
        this.required = required;
    }
     /**
     * Set attribute corresponding to the "validatorExpression" property
     */
    private MethodExpression validatorExpression = null;
    public void setValidatorExpression (MethodExpression validatorExpression) {
        this.validatorExpression = validatorExpression;
    }
     /**
     * Set attribute corresponding to the "rendered" property
     */
    private ValueExpression rendered = null;
    public void setRendered (ValueExpression rendered) {
        this.rendered = rendered;
    }
      /**
     * Set attribute corresponding to the "valueChangeListenerExpression" property
     */
    private MethodExpression valueChangeListenerExpression = null;
    public void setValueChangeListenerExpression (MethodExpression valueChangeListenerExpression) {
        this.valueChangeListenerExpression = valueChangeListenerExpression;
    }
       /**
     * Set attribute corresponding to the "loginController" property
     */
    private ValueExpression loginController = null;
    public void setLoginController (ValueExpression loginController) {
        this.loginController = loginController;
    }
     /**
     * Set attribute corresponding to the "htmlTemplate" property
     */
    private ValueExpression htmlTemplate = null;
    public void setHtmlTemplate (ValueExpression htmlTemplate) {
        this.htmlTemplate = htmlTemplate;
    }
     /**
     * Set attribute corresponding to the "styleClass" property
     */
    private ValueExpression styleClass = null;
    public void setStyleClass (ValueExpression styleClass) {
        this.styleClass = styleClass;
    }
      /**
     * Set attribute corresponding to the "immediate" property
     */
    private ValueExpression immediate = null;
    public void setImmediate (ValueExpression immediate) {
        this.immediate = immediate;
    }
      /**
     * Set attribute corresponding to the "serviceName" property
     */
    private ValueExpression serviceName = null;
    public void setServiceName (ValueExpression serviceName) {
        this.serviceName = serviceName;
    }
      /**
     * Set attribute corresponding to the "style" property
     */
    private ValueExpression style = null;
    public void setStyle (ValueExpression style) {
        this.style = style;
    }
     /**
     * Set attribute corresponding to the "redirectURL" property
     */
    private ValueExpression redirectURL = null;
    public void setRedirectURL (ValueExpression redirectURL) {
        this.redirectURL = redirectURL;
    }
     /**
     * Set attribute corresponding to the "tabIndex" property
     */
    private ValueExpression tabIndex = null;
    public void setTabIndex (ValueExpression tabIndex) {
        this.tabIndex = tabIndex;
    }
     /**
     * Set attribute corresponding to the "autoStart" property
     */
    private ValueExpression autoStart = null;
    public void setAutoStart (ValueExpression autoStart) {
        this.autoStart = autoStart;
    }
  
}
