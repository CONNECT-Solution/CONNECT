
package com.sun.webui.jsf.component;

import javax.el.ELException;
import javax.el.MethodExpression;
import javax.el.ValueExpression;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.faces.component.StateHolder;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.webapp.UIComponentELTag;
import javax.faces.context.FacesContext;

/**
 * This file was generated automatically on Mar 20, 2008.
 */

public class AnchorTag extends UIComponentELTag {
    
    /**
     * Returns the requested component type.
     */
    public String getComponentType() {
        return "com.sun.webui.jsf.Anchor";
    }
    
    /**
     * Returns the requested renderer type.
     */
    public String getRendererType() {
        return "com.sun.webui.jsf.widget.Anchor";
    }
    
    /**
     * Release any allocated tag handler attributes.
     */
    public void release() {
        super.release();
        rendered = null;
        shape = null;
        onKeyPress = null;
        target = null;
        onFocus = null;
        charset = null;
        urlLang = null;
        rev = null;
        onKeyUp = null;
        onMouseUp = null;
        styleClass = null;
        style = null;
        url = null;
        onClick = null;
        onBlur = null;
        toolTip = null;
        onMouseDown = null;
        type = null;
        disabled = null;
        accessKey = null;
        onMouseOut = null;
        onMouseOver = null;
        htmlTemplate = null;
        onMouseMove = null;
        text = null;
        rel = null;
        visible = null;
        onKeyDown = null;
        tabIndex = null;
        coords = null;
    }
    
    /**
     * Transfer tag attribute values to component properties.
     */
    protected void setProperties(UIComponent component) {
        super.setProperties(component);
                        
        if (rendered != null) {
            component.setValueExpression("rendered", rendered);
        }
        if (shape != null) {
            component.setValueExpression("shape", shape);
        }
        if (onKeyPress != null) {
            component.setValueExpression("onKeyPress", onKeyPress);
        }
        if (target != null) {
            component.setValueExpression("target", target);
        }
        if (onFocus != null) {
            component.setValueExpression("onFocus", onFocus);
        }
        if (charset != null) {
            component.setValueExpression("charset", charset);
        }
        if (urlLang != null) {
            component.setValueExpression("urlLang", urlLang);
        }
        if (rev != null) {
            component.setValueExpression("rev", rev);
        }
        if (onKeyUp != null) {
            component.setValueExpression("onKeyUp", onKeyUp);
        }
        if (onMouseUp != null) {
            component.setValueExpression("onMouseUp", onMouseUp);
        }
        if (styleClass != null) {
            component.setValueExpression("styleClass", styleClass);
        }
        if (style != null) {
            component.setValueExpression("style", style);
        }
        if (url != null) {
            component.setValueExpression("url", url);
        }
        if (onClick != null) {
            component.setValueExpression("onClick", onClick);
        }
        if (onBlur != null) {
            component.setValueExpression("onBlur", onBlur);
        }
        if (toolTip != null) {
            component.setValueExpression("toolTip", toolTip);
        }
        if (onMouseDown != null) {
            component.setValueExpression("onMouseDown", onMouseDown);
        }
        if (type != null) {
            component.setValueExpression("type", type);
        }
        if (disabled != null) {
            component.setValueExpression("disabled", disabled);
        }
        if (accessKey != null) {
            component.setValueExpression("accessKey", accessKey);
        }
        if (onMouseOut != null) {
            component.setValueExpression("onMouseOut", onMouseOut);
        }
        if (onMouseOver != null) {
            component.setValueExpression("onMouseOver", onMouseOver);
        }
        if (htmlTemplate != null) {
            component.setValueExpression("htmlTemplate", htmlTemplate);
        }
        if (onMouseMove != null) {
            component.setValueExpression("onMouseMove", onMouseMove);
        }
        if (text != null) {
            component.setValueExpression("text", text);
        }
        if (rel != null) {
            component.setValueExpression("rel", rel);
        }
        if (visible != null) {
            component.setValueExpression("visible", visible);
        }
        if (onKeyDown != null) {
            component.setValueExpression("onKeyDown", onKeyDown);
        }
        if (tabIndex != null) {
            component.setValueExpression("tabIndex", tabIndex);
        }
        if (coords != null) {
            component.setValueExpression("coords", coords);
        }
     }
    

    /**
     * Set attribute corresponding to the "rendered" property
     */
    private ValueExpression rendered = null;
    public void setRendered (ValueExpression rendered) {
        this.rendered = rendered;
    }
       /**
     * Set attribute corresponding to the "shape" property
     */
    private ValueExpression shape = null;
    public void setShape (ValueExpression shape) {
        this.shape = shape;
    }
     /**
     * Set attribute corresponding to the "onKeyPress" property
     */
    private ValueExpression onKeyPress = null;
    public void setOnKeyPress (ValueExpression onKeyPress) {
        this.onKeyPress = onKeyPress;
    }
     /**
     * Set attribute corresponding to the "target" property
     */
    private ValueExpression target = null;
    public void setTarget (ValueExpression target) {
        this.target = target;
    }
     /**
     * Set attribute corresponding to the "onFocus" property
     */
    private ValueExpression onFocus = null;
    public void setOnFocus (ValueExpression onFocus) {
        this.onFocus = onFocus;
    }
     /**
     * Set attribute corresponding to the "charset" property
     */
    private ValueExpression charset = null;
    public void setCharset (ValueExpression charset) {
        this.charset = charset;
    }
     /**
     * Set attribute corresponding to the "urlLang" property
     */
    private ValueExpression urlLang = null;
    public void setUrlLang (ValueExpression urlLang) {
        this.urlLang = urlLang;
    }
     /**
     * Set attribute corresponding to the "rev" property
     */
    private ValueExpression rev = null;
    public void setRev (ValueExpression rev) {
        this.rev = rev;
    }
     /**
     * Set attribute corresponding to the "onKeyUp" property
     */
    private ValueExpression onKeyUp = null;
    public void setOnKeyUp (ValueExpression onKeyUp) {
        this.onKeyUp = onKeyUp;
    }
     /**
     * Set attribute corresponding to the "onMouseUp" property
     */
    private ValueExpression onMouseUp = null;
    public void setOnMouseUp (ValueExpression onMouseUp) {
        this.onMouseUp = onMouseUp;
    }
     /**
     * Set attribute corresponding to the "styleClass" property
     */
    private ValueExpression styleClass = null;
    public void setStyleClass (ValueExpression styleClass) {
        this.styleClass = styleClass;
    }
     /**
     * Set attribute corresponding to the "style" property
     */
    private ValueExpression style = null;
    public void setStyle (ValueExpression style) {
        this.style = style;
    }
     /**
     * Set attribute corresponding to the "url" property
     */
    private ValueExpression url = null;
    public void setUrl (ValueExpression url) {
        this.url = url;
    }
     /**
     * Set attribute corresponding to the "onClick" property
     */
    private ValueExpression onClick = null;
    public void setOnClick (ValueExpression onClick) {
        this.onClick = onClick;
    }
     /**
     * Set attribute corresponding to the "onBlur" property
     */
    private ValueExpression onBlur = null;
    public void setOnBlur (ValueExpression onBlur) {
        this.onBlur = onBlur;
    }
     /**
     * Set attribute corresponding to the "toolTip" property
     */
    private ValueExpression toolTip = null;
    public void setToolTip (ValueExpression toolTip) {
        this.toolTip = toolTip;
    }
     /**
     * Set attribute corresponding to the "onMouseDown" property
     */
    private ValueExpression onMouseDown = null;
    public void setOnMouseDown (ValueExpression onMouseDown) {
        this.onMouseDown = onMouseDown;
    }
     /**
     * Set attribute corresponding to the "type" property
     */
    private ValueExpression type = null;
    public void setType (ValueExpression type) {
        this.type = type;
    }
     /**
     * Set attribute corresponding to the "disabled" property
     */
    private ValueExpression disabled = null;
    public void setDisabled (ValueExpression disabled) {
        this.disabled = disabled;
    }
     /**
     * Set attribute corresponding to the "accessKey" property
     */
    private ValueExpression accessKey = null;
    public void setAccessKey (ValueExpression accessKey) {
        this.accessKey = accessKey;
    }
     /**
     * Set attribute corresponding to the "onMouseOut" property
     */
    private ValueExpression onMouseOut = null;
    public void setOnMouseOut (ValueExpression onMouseOut) {
        this.onMouseOut = onMouseOut;
    }
     /**
     * Set attribute corresponding to the "onMouseOver" property
     */
    private ValueExpression onMouseOver = null;
    public void setOnMouseOver (ValueExpression onMouseOver) {
        this.onMouseOver = onMouseOver;
    }
     /**
     * Set attribute corresponding to the "htmlTemplate" property
     */
    private ValueExpression htmlTemplate = null;
    public void setHtmlTemplate (ValueExpression htmlTemplate) {
        this.htmlTemplate = htmlTemplate;
    }
     /**
     * Set attribute corresponding to the "onMouseMove" property
     */
    private ValueExpression onMouseMove = null;
    public void setOnMouseMove (ValueExpression onMouseMove) {
        this.onMouseMove = onMouseMove;
    }
     /**
     * Set attribute corresponding to the "text" property
     */
    private ValueExpression text = null;
    public void setText (ValueExpression text) {
        this.text = text;
    }
     /**
     * Set attribute corresponding to the "rel" property
     */
    private ValueExpression rel = null;
    public void setRel (ValueExpression rel) {
        this.rel = rel;
    }
     /**
     * Set attribute corresponding to the "visible" property
     */
    private ValueExpression visible = null;
    public void setVisible (ValueExpression visible) {
        this.visible = visible;
    }
     /**
     * Set attribute corresponding to the "onKeyDown" property
     */
    private ValueExpression onKeyDown = null;
    public void setOnKeyDown (ValueExpression onKeyDown) {
        this.onKeyDown = onKeyDown;
    }
     /**
     * Set attribute corresponding to the "tabIndex" property
     */
    private ValueExpression tabIndex = null;
    public void setTabIndex (ValueExpression tabIndex) {
        this.tabIndex = tabIndex;
    }
     /**
     * Set attribute corresponding to the "coords" property
     */
    private ValueExpression coords = null;
    public void setCoords (ValueExpression coords) {
        this.coords = coords;
    }
  
}
