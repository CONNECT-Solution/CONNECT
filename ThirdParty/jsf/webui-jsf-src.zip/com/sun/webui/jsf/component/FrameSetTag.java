
package com.sun.webui.jsf.component;

import javax.el.ELException;
import javax.el.MethodExpression;
import javax.el.ValueExpression;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.faces.component.StateHolder;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.webapp.UIComponentELTag;
import javax.faces.context.FacesContext;

/**
 * This file was generated automatically on Mar 20, 2008.
 */

public class FrameSetTag extends UIComponentELTag {
    
    /**
     * Returns the requested component type.
     */
    public String getComponentType() {
        return "com.sun.webui.jsf.FrameSet";
    }
    
    /**
     * Returns the requested renderer type.
     */
    public String getRendererType() {
        return "com.sun.webui.jsf.FrameSet";
    }
    
    /**
     * Release any allocated tag handler attributes.
     */
    public void release() {
        super.release();
        toolTip = null;
        cols = null;
        borderColor = null;
        styleClass = null;
        rows = null;
        style = null;
        frameBorder = null;
        border = null;
        rendered = null;
        frameSpacing = null;
    }
    
    /**
     * Transfer tag attribute values to component properties.
     */
    protected void setProperties(UIComponent component) {
        super.setProperties(component);
                        
        if (toolTip != null) {
            component.setValueExpression("toolTip", toolTip);
        }
        if (cols != null) {
            component.setValueExpression("cols", cols);
        }
        if (borderColor != null) {
            component.setValueExpression("borderColor", borderColor);
        }
        if (styleClass != null) {
            component.setValueExpression("styleClass", styleClass);
        }
        if (rows != null) {
            component.setValueExpression("rows", rows);
        }
        if (style != null) {
            component.setValueExpression("style", style);
        }
        if (frameBorder != null) {
            component.setValueExpression("frameBorder", frameBorder);
        }
        if (border != null) {
            component.setValueExpression("border", border);
        }
        if (rendered != null) {
            component.setValueExpression("rendered", rendered);
        }
        if (frameSpacing != null) {
            component.setValueExpression("frameSpacing", frameSpacing);
        }
     }
    

    /**
     * Set attribute corresponding to the "toolTip" property
     */
    private ValueExpression toolTip = null;
    public void setToolTip (ValueExpression toolTip) {
        this.toolTip = toolTip;
    }
     /**
     * Set attribute corresponding to the "cols" property
     */
    private ValueExpression cols = null;
    public void setCols (ValueExpression cols) {
        this.cols = cols;
    }
     /**
     * Set attribute corresponding to the "borderColor" property
     */
    private ValueExpression borderColor = null;
    public void setBorderColor (ValueExpression borderColor) {
        this.borderColor = borderColor;
    }
     /**
     * Set attribute corresponding to the "styleClass" property
     */
    private ValueExpression styleClass = null;
    public void setStyleClass (ValueExpression styleClass) {
        this.styleClass = styleClass;
    }
     /**
     * Set attribute corresponding to the "rows" property
     */
    private ValueExpression rows = null;
    public void setRows (ValueExpression rows) {
        this.rows = rows;
    }
     /**
     * Set attribute corresponding to the "style" property
     */
    private ValueExpression style = null;
    public void setStyle (ValueExpression style) {
        this.style = style;
    }
     /**
     * Set attribute corresponding to the "frameBorder" property
     */
    private ValueExpression frameBorder = null;
    public void setFrameBorder (ValueExpression frameBorder) {
        this.frameBorder = frameBorder;
    }
     /**
     * Set attribute corresponding to the "border" property
     */
    private ValueExpression border = null;
    public void setBorder (ValueExpression border) {
        this.border = border;
    }
     /**
     * Set attribute corresponding to the "rendered" property
     */
    private ValueExpression rendered = null;
    public void setRendered (ValueExpression rendered) {
        this.rendered = rendered;
    }
     /**
     * Set attribute corresponding to the "frameSpacing" property
     */
    private ValueExpression frameSpacing = null;
    public void setFrameSpacing (ValueExpression frameSpacing) {
        this.frameSpacing = frameSpacing;
    }
   
}
