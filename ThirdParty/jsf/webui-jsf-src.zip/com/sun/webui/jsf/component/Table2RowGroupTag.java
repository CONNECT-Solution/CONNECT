
package com.sun.webui.jsf.component;

import javax.el.ELException;
import javax.el.MethodExpression;
import javax.el.ValueExpression;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.faces.component.StateHolder;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.webapp.UIComponentELTag;
import javax.faces.context.FacesContext;

/**
 * This file was generated automatically on Mar 20, 2008.
 */

public class Table2RowGroupTag extends UIComponentELTag {
    
    /**
     * Returns the requested component type.
     */
    public String getComponentType() {
        return "com.sun.webui.jsf.Table2RowGroup";
    }
    
    /**
     * Returns the requested renderer type.
     */
    public String getRendererType() {
        return "com.sun.webui.jsf.widget.Table2RowGroup";
    }
    
    /**
     * Release any allocated tag handler attributes.
     */
    public void release() {
        super.release();
        onDblClick = null;
        tableDataSorter = null;
        onKeyPress = null;
        rendered = null;
        sourceData = null;
        onKeyUp = null;
        onMouseUp = null;
        align = null;
        selectMultipleToggleButton = null;
        onClick = null;
        groupToggleButton = null;
        toolTip = null;
        onMouseDown = null;
        tableDataFilter = null;
        rows = null;
        sourceVar = null;
        valign = null;
        first = null;
        onMouseOut = null;
        onMouseOver = null;
        onMouseMove = null;
        emptyDataMsg = null;
        selected = null;
        collapsed = null;
        visible = null;
        onKeyDown = null;
        headerText = null;
        styleClasses = null;
        htmlTemplate = null;
        paginationControls = null;
    }
    
    /**
     * Transfer tag attribute values to component properties.
     */
    protected void setProperties(UIComponent component) {
        super.setProperties(component);
                        
        if (onDblClick != null) {
            component.setValueExpression("onDblClick", onDblClick);
        }
        if (tableDataSorter != null) {
            component.setValueExpression("tableDataSorter", tableDataSorter);
        }
        if (onKeyPress != null) {
            component.setValueExpression("onKeyPress", onKeyPress);
        }
        if (rendered != null) {
            component.setValueExpression("rendered", rendered);
        }
        if (sourceData != null) {
            component.setValueExpression("sourceData", sourceData);
        }
        if (onKeyUp != null) {
            component.setValueExpression("onKeyUp", onKeyUp);
        }
        if (onMouseUp != null) {
            component.setValueExpression("onMouseUp", onMouseUp);
        }
        if (align != null) {
            component.setValueExpression("align", align);
        }
        if (selectMultipleToggleButton != null) {
            component.setValueExpression("selectMultipleToggleButton", selectMultipleToggleButton);
        }
        if (onClick != null) {
            component.setValueExpression("onClick", onClick);
        }
        if (groupToggleButton != null) {
            component.setValueExpression("groupToggleButton", groupToggleButton);
        }
        if (toolTip != null) {
            component.setValueExpression("toolTip", toolTip);
        }
        if (onMouseDown != null) {
            component.setValueExpression("onMouseDown", onMouseDown);
        }
        if (tableDataFilter != null) {
            component.setValueExpression("tableDataFilter", tableDataFilter);
        }
        if (rows != null) {
            component.setValueExpression("rows", rows);
        }
        if (sourceVar != null) {
            component.setValueExpression("sourceVar", sourceVar);
        }
        if (valign != null) {
            component.setValueExpression("valign", valign);
        }
        if (first != null) {
            component.setValueExpression("first", first);
        }
        if (onMouseOut != null) {
            component.setValueExpression("onMouseOut", onMouseOut);
        }
        if (onMouseOver != null) {
            component.setValueExpression("onMouseOver", onMouseOver);
        }
        if (onMouseMove != null) {
            component.setValueExpression("onMouseMove", onMouseMove);
        }
        if (emptyDataMsg != null) {
            component.setValueExpression("emptyDataMsg", emptyDataMsg);
        }
        if (selected != null) {
            component.setValueExpression("selected", selected);
        }
        if (collapsed != null) {
            component.setValueExpression("collapsed", collapsed);
        }
        if (visible != null) {
            component.setValueExpression("visible", visible);
        }
        if (onKeyDown != null) {
            component.setValueExpression("onKeyDown", onKeyDown);
        }
        if (headerText != null) {
            component.setValueExpression("headerText", headerText);
        }
        if (styleClasses != null) {
            component.setValueExpression("styleClasses", styleClasses);
        }
        if (htmlTemplate != null) {
            component.setValueExpression("htmlTemplate", htmlTemplate);
        }
        if (paginationControls != null) {
            component.setValueExpression("paginationControls", paginationControls);
        }
     }
    

    /**
     * Set attribute corresponding to the "onDblClick" property
     */
    private ValueExpression onDblClick = null;
    public void setOnDblClick (ValueExpression onDblClick) {
        this.onDblClick = onDblClick;
    }
     /**
     * Set attribute corresponding to the "tableDataSorter" property
     */
    private ValueExpression tableDataSorter = null;
    public void setTableDataSorter (ValueExpression tableDataSorter) {
        this.tableDataSorter = tableDataSorter;
    }
     /**
     * Set attribute corresponding to the "onKeyPress" property
     */
    private ValueExpression onKeyPress = null;
    public void setOnKeyPress (ValueExpression onKeyPress) {
        this.onKeyPress = onKeyPress;
    }
     /**
     * Set attribute corresponding to the "rendered" property
     */
    private ValueExpression rendered = null;
    public void setRendered (ValueExpression rendered) {
        this.rendered = rendered;
    }
     /**
     * Set attribute corresponding to the "sourceData" property
     */
    private ValueExpression sourceData = null;
    public void setSourceData (ValueExpression sourceData) {
        this.sourceData = sourceData;
    }
       /**
     * Set attribute corresponding to the "onKeyUp" property
     */
    private ValueExpression onKeyUp = null;
    public void setOnKeyUp (ValueExpression onKeyUp) {
        this.onKeyUp = onKeyUp;
    }
     /**
     * Set attribute corresponding to the "onMouseUp" property
     */
    private ValueExpression onMouseUp = null;
    public void setOnMouseUp (ValueExpression onMouseUp) {
        this.onMouseUp = onMouseUp;
    }
      /**
     * Set attribute corresponding to the "align" property
     */
    private ValueExpression align = null;
    public void setAlign (ValueExpression align) {
        this.align = align;
    }
     /**
     * Set attribute corresponding to the "selectMultipleToggleButton" property
     */
    private ValueExpression selectMultipleToggleButton = null;
    public void setSelectMultipleToggleButton (ValueExpression selectMultipleToggleButton) {
        this.selectMultipleToggleButton = selectMultipleToggleButton;
    }
      /**
     * Set attribute corresponding to the "onClick" property
     */
    private ValueExpression onClick = null;
    public void setOnClick (ValueExpression onClick) {
        this.onClick = onClick;
    }
     /**
     * Set attribute corresponding to the "groupToggleButton" property
     */
    private ValueExpression groupToggleButton = null;
    public void setGroupToggleButton (ValueExpression groupToggleButton) {
        this.groupToggleButton = groupToggleButton;
    }
     /**
     * Set attribute corresponding to the "toolTip" property
     */
    private ValueExpression toolTip = null;
    public void setToolTip (ValueExpression toolTip) {
        this.toolTip = toolTip;
    }
     /**
     * Set attribute corresponding to the "onMouseDown" property
     */
    private ValueExpression onMouseDown = null;
    public void setOnMouseDown (ValueExpression onMouseDown) {
        this.onMouseDown = onMouseDown;
    }
     /**
     * Set attribute corresponding to the "tableDataFilter" property
     */
    private ValueExpression tableDataFilter = null;
    public void setTableDataFilter (ValueExpression tableDataFilter) {
        this.tableDataFilter = tableDataFilter;
    }
     /**
     * Set attribute corresponding to the "rows" property
     */
    private ValueExpression rows = null;
    public void setRows (ValueExpression rows) {
        this.rows = rows;
    }
     /**
     * Set attribute corresponding to the "sourceVar" property
     */
    private ValueExpression sourceVar = null;
    public void setSourceVar (ValueExpression sourceVar) {
        this.sourceVar = sourceVar;
    }
     /**
     * Set attribute corresponding to the "valign" property
     */
    private ValueExpression valign = null;
    public void setValign (ValueExpression valign) {
        this.valign = valign;
    }
     /**
     * Set attribute corresponding to the "first" property
     */
    private ValueExpression first = null;
    public void setFirst (ValueExpression first) {
        this.first = first;
    }
     /**
     * Set attribute corresponding to the "onMouseOut" property
     */
    private ValueExpression onMouseOut = null;
    public void setOnMouseOut (ValueExpression onMouseOut) {
        this.onMouseOut = onMouseOut;
    }
     /**
     * Set attribute corresponding to the "onMouseOver" property
     */
    private ValueExpression onMouseOver = null;
    public void setOnMouseOver (ValueExpression onMouseOver) {
        this.onMouseOver = onMouseOver;
    }
     /**
     * Set attribute corresponding to the "onMouseMove" property
     */
    private ValueExpression onMouseMove = null;
    public void setOnMouseMove (ValueExpression onMouseMove) {
        this.onMouseMove = onMouseMove;
    }
     /**
     * Set attribute corresponding to the "emptyDataMsg" property
     */
    private ValueExpression emptyDataMsg = null;
    public void setEmptyDataMsg (ValueExpression emptyDataMsg) {
        this.emptyDataMsg = emptyDataMsg;
    }
     /**
     * Set attribute corresponding to the "selected" property
     */
    private ValueExpression selected = null;
    public void setSelected (ValueExpression selected) {
        this.selected = selected;
    }
     /**
     * Set attribute corresponding to the "collapsed" property
     */
    private ValueExpression collapsed = null;
    public void setCollapsed (ValueExpression collapsed) {
        this.collapsed = collapsed;
    }
     /**
     * Set attribute corresponding to the "visible" property
     */
    private ValueExpression visible = null;
    public void setVisible (ValueExpression visible) {
        this.visible = visible;
    }
     /**
     * Set attribute corresponding to the "onKeyDown" property
     */
    private ValueExpression onKeyDown = null;
    public void setOnKeyDown (ValueExpression onKeyDown) {
        this.onKeyDown = onKeyDown;
    }
     /**
     * Set attribute corresponding to the "headerText" property
     */
    private ValueExpression headerText = null;
    public void setHeaderText (ValueExpression headerText) {
        this.headerText = headerText;
    }
     /**
     * Set attribute corresponding to the "styleClasses" property
     */
    private ValueExpression styleClasses = null;
    public void setStyleClasses (ValueExpression styleClasses) {
        this.styleClasses = styleClasses;
    }
     /**
     * Set attribute corresponding to the "htmlTemplate" property
     */
    private ValueExpression htmlTemplate = null;
    public void setHtmlTemplate (ValueExpression htmlTemplate) {
        this.htmlTemplate = htmlTemplate;
    }
     /**
     * Set attribute corresponding to the "paginationControls" property
     */
    private ValueExpression paginationControls = null;
    public void setPaginationControls (ValueExpression paginationControls) {
        this.paginationControls = paginationControls;
    }
  
}
