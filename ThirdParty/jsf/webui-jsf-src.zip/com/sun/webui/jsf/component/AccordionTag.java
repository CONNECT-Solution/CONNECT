
package com.sun.webui.jsf.component;

import javax.el.ELException;
import javax.el.MethodExpression;
import javax.el.ValueExpression;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.faces.component.StateHolder;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.webapp.UIComponentELTag;
import javax.faces.context.FacesContext;

/**
 * This file was generated automatically on Mar 20, 2008.
 */

public class AccordionTag extends UIComponentELTag {
    
    /**
     * Returns the requested component type.
     */
    public String getComponentType() {
        return "com.sun.webui.jsf.Accordion";
    }
    
    /**
     * Returns the requested renderer type.
     */
    public String getRendererType() {
        return "com.sun.webui.jsf.widget.Accordion";
    }
    
    /**
     * Release any allocated tag handler attributes.
     */
    public void release() {
        super.release();
        htmlTemplate = null;
        loadOnSelect = null;
        styleClass = null;
        selectedTabs = null;
        style = null;
        visible = null;
        rendered = null;
        tabIndex = null;
        refreshIcon = null;
        multipleSelect = null;
        toggleControls = null;
    }
    
    /**
     * Transfer tag attribute values to component properties.
     */
    protected void setProperties(UIComponent component) {
        super.setProperties(component);
                        
        if (htmlTemplate != null) {
            component.setValueExpression("htmlTemplate", htmlTemplate);
        }
        if (loadOnSelect != null) {
            component.setValueExpression("loadOnSelect", loadOnSelect);
        }
        if (styleClass != null) {
            component.setValueExpression("styleClass", styleClass);
        }
        if (selectedTabs != null) {
            component.setValueExpression("selectedTabs", selectedTabs);
        }
        if (style != null) {
            component.setValueExpression("style", style);
        }
        if (visible != null) {
            component.setValueExpression("visible", visible);
        }
        if (rendered != null) {
            component.setValueExpression("rendered", rendered);
        }
        if (tabIndex != null) {
            component.setValueExpression("tabIndex", tabIndex);
        }
        if (refreshIcon != null) {
            component.setValueExpression("refreshIcon", refreshIcon);
        }
        if (multipleSelect != null) {
            component.setValueExpression("multipleSelect", multipleSelect);
        }
        if (toggleControls != null) {
            component.setValueExpression("toggleControls", toggleControls);
        }
     }
    

    /**
     * Set attribute corresponding to the "htmlTemplate" property
     */
    private ValueExpression htmlTemplate = null;
    public void setHtmlTemplate (ValueExpression htmlTemplate) {
        this.htmlTemplate = htmlTemplate;
    }
     /**
     * Set attribute corresponding to the "loadOnSelect" property
     */
    private ValueExpression loadOnSelect = null;
    public void setLoadOnSelect (ValueExpression loadOnSelect) {
        this.loadOnSelect = loadOnSelect;
    }
     /**
     * Set attribute corresponding to the "styleClass" property
     */
    private ValueExpression styleClass = null;
    public void setStyleClass (ValueExpression styleClass) {
        this.styleClass = styleClass;
    }
     /**
     * Set attribute corresponding to the "selectedTabs" property
     */
    private ValueExpression selectedTabs = null;
    public void setSelectedTabs (ValueExpression selectedTabs) {
        this.selectedTabs = selectedTabs;
    }
     /**
     * Set attribute corresponding to the "style" property
     */
    private ValueExpression style = null;
    public void setStyle (ValueExpression style) {
        this.style = style;
    }
     /**
     * Set attribute corresponding to the "visible" property
     */
    private ValueExpression visible = null;
    public void setVisible (ValueExpression visible) {
        this.visible = visible;
    }
     /**
     * Set attribute corresponding to the "rendered" property
     */
    private ValueExpression rendered = null;
    public void setRendered (ValueExpression rendered) {
        this.rendered = rendered;
    }
     /**
     * Set attribute corresponding to the "tabIndex" property
     */
    private ValueExpression tabIndex = null;
    public void setTabIndex (ValueExpression tabIndex) {
        this.tabIndex = tabIndex;
    }
      /**
     * Set attribute corresponding to the "refreshIcon" property
     */
    private ValueExpression refreshIcon = null;
    public void setRefreshIcon (ValueExpression refreshIcon) {
        this.refreshIcon = refreshIcon;
    }
     /**
     * Set attribute corresponding to the "multipleSelect" property
     */
    private ValueExpression multipleSelect = null;
    public void setMultipleSelect (ValueExpression multipleSelect) {
        this.multipleSelect = multipleSelect;
    }
     /**
     * Set attribute corresponding to the "toggleControls" property
     */
    private ValueExpression toggleControls = null;
    public void setToggleControls (ValueExpression toggleControls) {
        this.toggleControls = toggleControls;
    }
  
}
