
package com.sun.webui.jsf.component;

import javax.el.ELException;
import javax.el.MethodExpression;
import javax.el.ValueExpression;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.faces.component.StateHolder;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.webapp.UIComponentELTag;
import javax.faces.context.FacesContext;

/**
 * This file was generated automatically on Mar 20, 2008.
 */

public class Table2Tag extends UIComponentELTag {
    
    /**
     * Returns the requested component type.
     */
    public String getComponentType() {
        return "com.sun.webui.jsf.Table2";
    }
    
    /**
     * Returns the requested renderer type.
     */
    public String getRendererType() {
        return "com.sun.webui.jsf.widget.Table2";
    }
    
    /**
     * Release any allocated tag handler attributes.
     */
    public void release() {
        super.release();
        onDblClick = null;
        width = null;
        title = null;
        onKeyPress = null;
        deselectMultipleButtonOnClick = null;
        clearSortButton = null;
        rendered = null;
        filterId = null;
        hiddenSelectedRows = null;
        onKeyUp = null;
        onMouseUp = null;
        styleClass = null;
        deselectMultipleButton = null;
        filterPanelFocusId = null;
        augmentTitle = null;
        lite = null;
        style = null;
        cellSpacing = null;
        onClick = null;
        filterText = null;
        toolTip = null;
        onMouseDown = null;
        sortPanelFocusId = null;
        summary = null;
        sortPanelToggleButton = null;
        selectMultipleButton = null;
        preferencesPanelFocusId = null;
        onMouseOut = null;
        paginateButton = null;
        selectMultipleButtonOnClick = null;
        onMouseOver = null;
        onMouseMove = null;
        cellPadding = null;
        deselectSingleButtonOnClick = null;
        itemsText = null;
        deselectSingleButton = null;
        visible = null;
        onKeyDown = null;
        tabIndex = null;
        htmlTemplate = null;
    }
    
    /**
     * Transfer tag attribute values to component properties.
     */
    protected void setProperties(UIComponent component) {
        super.setProperties(component);
                        
        if (onDblClick != null) {
            component.setValueExpression("onDblClick", onDblClick);
        }
        if (width != null) {
            component.setValueExpression("width", width);
        }
        if (title != null) {
            component.setValueExpression("title", title);
        }
        if (onKeyPress != null) {
            component.setValueExpression("onKeyPress", onKeyPress);
        }
        if (deselectMultipleButtonOnClick != null) {
            component.setValueExpression("deselectMultipleButtonOnClick", deselectMultipleButtonOnClick);
        }
        if (clearSortButton != null) {
            component.setValueExpression("clearSortButton", clearSortButton);
        }
        if (rendered != null) {
            component.setValueExpression("rendered", rendered);
        }
        if (filterId != null) {
            component.setValueExpression("filterId", filterId);
        }
        if (hiddenSelectedRows != null) {
            component.setValueExpression("hiddenSelectedRows", hiddenSelectedRows);
        }
        if (onKeyUp != null) {
            component.setValueExpression("onKeyUp", onKeyUp);
        }
        if (onMouseUp != null) {
            component.setValueExpression("onMouseUp", onMouseUp);
        }
        if (styleClass != null) {
            component.setValueExpression("styleClass", styleClass);
        }
        if (deselectMultipleButton != null) {
            component.setValueExpression("deselectMultipleButton", deselectMultipleButton);
        }
        if (filterPanelFocusId != null) {
            component.setValueExpression("filterPanelFocusId", filterPanelFocusId);
        }
        if (augmentTitle != null) {
            component.setValueExpression("augmentTitle", augmentTitle);
        }
        if (lite != null) {
            component.setValueExpression("lite", lite);
        }
        if (style != null) {
            component.setValueExpression("style", style);
        }
        if (cellSpacing != null) {
            component.setValueExpression("cellSpacing", cellSpacing);
        }
        if (onClick != null) {
            component.setValueExpression("onClick", onClick);
        }
        if (filterText != null) {
            component.setValueExpression("filterText", filterText);
        }
        if (toolTip != null) {
            component.setValueExpression("toolTip", toolTip);
        }
        if (onMouseDown != null) {
            component.setValueExpression("onMouseDown", onMouseDown);
        }
        if (sortPanelFocusId != null) {
            component.setValueExpression("sortPanelFocusId", sortPanelFocusId);
        }
        if (summary != null) {
            component.setValueExpression("summary", summary);
        }
        if (sortPanelToggleButton != null) {
            component.setValueExpression("sortPanelToggleButton", sortPanelToggleButton);
        }
        if (selectMultipleButton != null) {
            component.setValueExpression("selectMultipleButton", selectMultipleButton);
        }
        if (preferencesPanelFocusId != null) {
            component.setValueExpression("preferencesPanelFocusId", preferencesPanelFocusId);
        }
        if (onMouseOut != null) {
            component.setValueExpression("onMouseOut", onMouseOut);
        }
        if (paginateButton != null) {
            component.setValueExpression("paginateButton", paginateButton);
        }
        if (selectMultipleButtonOnClick != null) {
            component.setValueExpression("selectMultipleButtonOnClick", selectMultipleButtonOnClick);
        }
        if (onMouseOver != null) {
            component.setValueExpression("onMouseOver", onMouseOver);
        }
        if (onMouseMove != null) {
            component.setValueExpression("onMouseMove", onMouseMove);
        }
        if (cellPadding != null) {
            component.setValueExpression("cellPadding", cellPadding);
        }
        if (deselectSingleButtonOnClick != null) {
            component.setValueExpression("deselectSingleButtonOnClick", deselectSingleButtonOnClick);
        }
        if (itemsText != null) {
            component.setValueExpression("itemsText", itemsText);
        }
        if (deselectSingleButton != null) {
            component.setValueExpression("deselectSingleButton", deselectSingleButton);
        }
        if (visible != null) {
            component.setValueExpression("visible", visible);
        }
        if (onKeyDown != null) {
            component.setValueExpression("onKeyDown", onKeyDown);
        }
        if (tabIndex != null) {
            component.setValueExpression("tabIndex", tabIndex);
        }
        if (htmlTemplate != null) {
            component.setValueExpression("htmlTemplate", htmlTemplate);
        }
     }
    

    /**
     * Set attribute corresponding to the "onDblClick" property
     */
    private ValueExpression onDblClick = null;
    public void setOnDblClick (ValueExpression onDblClick) {
        this.onDblClick = onDblClick;
    }
     /**
     * Set attribute corresponding to the "width" property
     */
    private ValueExpression width = null;
    public void setWidth (ValueExpression width) {
        this.width = width;
    }
     /**
     * Set attribute corresponding to the "title" property
     */
    private ValueExpression title = null;
    public void setTitle (ValueExpression title) {
        this.title = title;
    }
     /**
     * Set attribute corresponding to the "onKeyPress" property
     */
    private ValueExpression onKeyPress = null;
    public void setOnKeyPress (ValueExpression onKeyPress) {
        this.onKeyPress = onKeyPress;
    }
      /**
     * Set attribute corresponding to the "deselectMultipleButtonOnClick" property
     */
    private ValueExpression deselectMultipleButtonOnClick = null;
    public void setDeselectMultipleButtonOnClick (ValueExpression deselectMultipleButtonOnClick) {
        this.deselectMultipleButtonOnClick = deselectMultipleButtonOnClick;
    }
     /**
     * Set attribute corresponding to the "clearSortButton" property
     */
    private ValueExpression clearSortButton = null;
    public void setClearSortButton (ValueExpression clearSortButton) {
        this.clearSortButton = clearSortButton;
    }
     /**
     * Set attribute corresponding to the "rendered" property
     */
    private ValueExpression rendered = null;
    public void setRendered (ValueExpression rendered) {
        this.rendered = rendered;
    }
     /**
     * Set attribute corresponding to the "filterId" property
     */
    private ValueExpression filterId = null;
    public void setFilterId (ValueExpression filterId) {
        this.filterId = filterId;
    }
      /**
     * Set attribute corresponding to the "hiddenSelectedRows" property
     */
    private ValueExpression hiddenSelectedRows = null;
    public void setHiddenSelectedRows (ValueExpression hiddenSelectedRows) {
        this.hiddenSelectedRows = hiddenSelectedRows;
    }
      /**
     * Set attribute corresponding to the "onKeyUp" property
     */
    private ValueExpression onKeyUp = null;
    public void setOnKeyUp (ValueExpression onKeyUp) {
        this.onKeyUp = onKeyUp;
    }
     /**
     * Set attribute corresponding to the "onMouseUp" property
     */
    private ValueExpression onMouseUp = null;
    public void setOnMouseUp (ValueExpression onMouseUp) {
        this.onMouseUp = onMouseUp;
    }
     /**
     * Set attribute corresponding to the "styleClass" property
     */
    private ValueExpression styleClass = null;
    public void setStyleClass (ValueExpression styleClass) {
        this.styleClass = styleClass;
    }
     /**
     * Set attribute corresponding to the "deselectMultipleButton" property
     */
    private ValueExpression deselectMultipleButton = null;
    public void setDeselectMultipleButton (ValueExpression deselectMultipleButton) {
        this.deselectMultipleButton = deselectMultipleButton;
    }
     /**
     * Set attribute corresponding to the "filterPanelFocusId" property
     */
    private ValueExpression filterPanelFocusId = null;
    public void setFilterPanelFocusId (ValueExpression filterPanelFocusId) {
        this.filterPanelFocusId = filterPanelFocusId;
    }
     /**
     * Set attribute corresponding to the "augmentTitle" property
     */
    private ValueExpression augmentTitle = null;
    public void setAugmentTitle (ValueExpression augmentTitle) {
        this.augmentTitle = augmentTitle;
    }
      /**
     * Set attribute corresponding to the "lite" property
     */
    private ValueExpression lite = null;
    public void setLite (ValueExpression lite) {
        this.lite = lite;
    }
     /**
     * Set attribute corresponding to the "style" property
     */
    private ValueExpression style = null;
    public void setStyle (ValueExpression style) {
        this.style = style;
    }
     /**
     * Set attribute corresponding to the "cellSpacing" property
     */
    private ValueExpression cellSpacing = null;
    public void setCellSpacing (ValueExpression cellSpacing) {
        this.cellSpacing = cellSpacing;
    }
      /**
     * Set attribute corresponding to the "onClick" property
     */
    private ValueExpression onClick = null;
    public void setOnClick (ValueExpression onClick) {
        this.onClick = onClick;
    }
     /**
     * Set attribute corresponding to the "filterText" property
     */
    private ValueExpression filterText = null;
    public void setFilterText (ValueExpression filterText) {
        this.filterText = filterText;
    }
     /**
     * Set attribute corresponding to the "toolTip" property
     */
    private ValueExpression toolTip = null;
    public void setToolTip (ValueExpression toolTip) {
        this.toolTip = toolTip;
    }
     /**
     * Set attribute corresponding to the "onMouseDown" property
     */
    private ValueExpression onMouseDown = null;
    public void setOnMouseDown (ValueExpression onMouseDown) {
        this.onMouseDown = onMouseDown;
    }
     /**
     * Set attribute corresponding to the "sortPanelFocusId" property
     */
    private ValueExpression sortPanelFocusId = null;
    public void setSortPanelFocusId (ValueExpression sortPanelFocusId) {
        this.sortPanelFocusId = sortPanelFocusId;
    }
     /**
     * Set attribute corresponding to the "summary" property
     */
    private ValueExpression summary = null;
    public void setSummary (ValueExpression summary) {
        this.summary = summary;
    }
     /**
     * Set attribute corresponding to the "sortPanelToggleButton" property
     */
    private ValueExpression sortPanelToggleButton = null;
    public void setSortPanelToggleButton (ValueExpression sortPanelToggleButton) {
        this.sortPanelToggleButton = sortPanelToggleButton;
    }
     /**
     * Set attribute corresponding to the "selectMultipleButton" property
     */
    private ValueExpression selectMultipleButton = null;
    public void setSelectMultipleButton (ValueExpression selectMultipleButton) {
        this.selectMultipleButton = selectMultipleButton;
    }
     /**
     * Set attribute corresponding to the "preferencesPanelFocusId" property
     */
    private ValueExpression preferencesPanelFocusId = null;
    public void setPreferencesPanelFocusId (ValueExpression preferencesPanelFocusId) {
        this.preferencesPanelFocusId = preferencesPanelFocusId;
    }
     /**
     * Set attribute corresponding to the "onMouseOut" property
     */
    private ValueExpression onMouseOut = null;
    public void setOnMouseOut (ValueExpression onMouseOut) {
        this.onMouseOut = onMouseOut;
    }
     /**
     * Set attribute corresponding to the "paginateButton" property
     */
    private ValueExpression paginateButton = null;
    public void setPaginateButton (ValueExpression paginateButton) {
        this.paginateButton = paginateButton;
    }
     /**
     * Set attribute corresponding to the "selectMultipleButtonOnClick" property
     */
    private ValueExpression selectMultipleButtonOnClick = null;
    public void setSelectMultipleButtonOnClick (ValueExpression selectMultipleButtonOnClick) {
        this.selectMultipleButtonOnClick = selectMultipleButtonOnClick;
    }
     /**
     * Set attribute corresponding to the "onMouseOver" property
     */
    private ValueExpression onMouseOver = null;
    public void setOnMouseOver (ValueExpression onMouseOver) {
        this.onMouseOver = onMouseOver;
    }
     /**
     * Set attribute corresponding to the "onMouseMove" property
     */
    private ValueExpression onMouseMove = null;
    public void setOnMouseMove (ValueExpression onMouseMove) {
        this.onMouseMove = onMouseMove;
    }
      /**
     * Set attribute corresponding to the "cellPadding" property
     */
    private ValueExpression cellPadding = null;
    public void setCellPadding (ValueExpression cellPadding) {
        this.cellPadding = cellPadding;
    }
     /**
     * Set attribute corresponding to the "deselectSingleButtonOnClick" property
     */
    private ValueExpression deselectSingleButtonOnClick = null;
    public void setDeselectSingleButtonOnClick (ValueExpression deselectSingleButtonOnClick) {
        this.deselectSingleButtonOnClick = deselectSingleButtonOnClick;
    }
     /**
     * Set attribute corresponding to the "itemsText" property
     */
    private ValueExpression itemsText = null;
    public void setItemsText (ValueExpression itemsText) {
        this.itemsText = itemsText;
    }
     /**
     * Set attribute corresponding to the "deselectSingleButton" property
     */
    private ValueExpression deselectSingleButton = null;
    public void setDeselectSingleButton (ValueExpression deselectSingleButton) {
        this.deselectSingleButton = deselectSingleButton;
    }
     /**
     * Set attribute corresponding to the "visible" property
     */
    private ValueExpression visible = null;
    public void setVisible (ValueExpression visible) {
        this.visible = visible;
    }
     /**
     * Set attribute corresponding to the "onKeyDown" property
     */
    private ValueExpression onKeyDown = null;
    public void setOnKeyDown (ValueExpression onKeyDown) {
        this.onKeyDown = onKeyDown;
    }
     /**
     * Set attribute corresponding to the "tabIndex" property
     */
    private ValueExpression tabIndex = null;
    public void setTabIndex (ValueExpression tabIndex) {
        this.tabIndex = tabIndex;
    }
     /**
     * Set attribute corresponding to the "htmlTemplate" property
     */
    private ValueExpression htmlTemplate = null;
    public void setHtmlTemplate (ValueExpression htmlTemplate) {
        this.htmlTemplate = htmlTemplate;
    }
  
}
