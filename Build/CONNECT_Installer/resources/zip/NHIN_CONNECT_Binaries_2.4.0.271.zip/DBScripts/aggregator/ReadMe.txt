This directory contains the scripts required for setting up the aggregator 
schema.  

1.  Create a new schema (catalog) called aggregator.
2.  Create a user called aggroot with password aggpass.
3.  Grant aggroot all privileges to the aggregator schema.
4.  Logon to mysql with user aggroot in schema: aggregator.
5.  Load and excecute aggregator.sql script to create the tables and keys.
