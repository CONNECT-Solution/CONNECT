GRANT SELECT,INSERT,UPDATE,ALTER,CREATE,DELETE ON docrepository.* to nhincuser;
commit;
